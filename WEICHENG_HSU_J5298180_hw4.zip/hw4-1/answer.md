- (a): 10 times
- (b): 9 times
- (c): compile error
- 
    /Users/poc/workspace/UCSC_courses/C_beginner/hw4-2/main.c:7:13: error: use of undeclared identifier 'i'
        while(++i < 10){
                ^
    /Users/poc/workspace/UCSC_courses/C_beginner/hw4-2/main.c:8:23: error: use of undeclared identifier 'i'
            printf("%s\n",i);
                          ^
